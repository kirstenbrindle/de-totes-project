def make_fact_sales_order(df):
    return df


# 3 additional rows
# 2 are splits of created at and last updated timestamps
# third is serial primary key of sales record_ID
# add prefix on to staff_id 

