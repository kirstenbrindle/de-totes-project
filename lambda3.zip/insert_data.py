def insert_data(conn, table_name, cols, new_data):
    pass
# poss don't need
