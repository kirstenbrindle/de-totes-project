def get_columns(conn, table_name):
    pass
# poss don't need
